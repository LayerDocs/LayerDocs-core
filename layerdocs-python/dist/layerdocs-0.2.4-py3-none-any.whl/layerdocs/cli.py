import subprocess
import sys
import os
import urllib.request
import zipfile
import shutil
import glob

class LayerDocs:
    """The Ultimate, Ultra-Lightweight LayerDocs Wrapper (v0.2.4)."""
    
    ENGINE_URL = "https://github.com/LayerDocs/LayerDocs-core/releases/latest/download/layerdocs.zip"
    
    def __init__(self, cli_path=None):
        self.cli_path = cli_path or self._find_or_install_engine()

    def _find_or_install_engine(self):
        # 1. Simple Check
        if shutil.which("layerdocs"):
            return "layerdocs"
        
        # 2. Local Check
        app_data = os.path.join(os.path.expanduser("~"), ".layerdocs")
        bin_name = "layerdocs.bat" if os.name == "nt" else "layerdocs"
        
        # Fast search (not recursive for better memory)
        for root, dirs, files in os.walk(app_data):
            if bin_name in files:
                return os.path.join(root, bin_name)
            
        # 3. Clean Install
        return self.download_engine()

    def download_engine(self):
        app_data = os.path.join(os.path.expanduser("~"), ".layerdocs")
        print(f"📥 Installing LayerDocs Engine to {app_data}...")
        
        if os.path.exists(app_data): shutil.rmtree(app_data, ignore_errors=True)
        os.makedirs(app_data, exist_ok=True)
        zip_path = os.path.join(app_data, "engine.zip")
        
        try:
            # Browser-like request to prevent blocks
            opener = urllib.request.build_opener()
            opener.addheaders = [('User-agent', 'Mozilla/5.0')]
            urllib.request.install_opener(opener)
            
            # Use urlretrieve for better stability in Colab
            urllib.request.urlretrieve(self.ENGINE_URL, zip_path)
            
            with zipfile.ZipFile(zip_path, "r") as zip_ref:
                zip_ref.extractall(app_data)
            os.remove(zip_path)
            
            # Find binary
            bin_name = "layerdocs.bat" if os.name == "nt" else "layerdocs"
            for root, dirs, files in os.walk(app_data):
                if bin_name in files:
                    full_path = os.path.join(root, bin_name)
                    if os.name != "nt": os.chmod(full_path, 0o755)
                    print(f"✅ Ready: {full_path}")
                    return full_path
                    
            raise FileNotFoundError("Engine binary missing from package.")
        except Exception as e:
            print(f"⚠️ Warning: Auto-install failed ({e}). Use manual installation.")
            return "layerdocs"

    def compile(self, file_path, output_dir=None):
        """Compiles a .qd file."""
        cmd = [self.cli_path, "c", file_path]
        if output_dir: cmd.extend(["-o", output_dir])
        # Use shell=False for better stability in Jupyter/Colab
        return subprocess.run(cmd, capture_output=True, text=True, shell=False)

def main():
    """Main CLI entry point."""
    ld = LayerDocs()
    # Filter out Jupyter arguments if running in Colab
    args = [a for a in sys.argv[1:] if not a.startswith("-f") and ".json" not in a]
    subprocess.run([ld.cli_path] + args)
